# Source Traceability · v2.2 FINAL LOCK

Host combat, roster, families, original resource census and motif authority: AVENGING_SPIRIT_REBORN_25_HOST_MASTER_DB_v2.2_FINAL_LOCK.xlsx.

Card definitions and approved recipe pairs: AVENGING_SPIRIT_REBORN_CARD_BUILD_EVOLUTION_MASTER_v2.2_CARD_RECIPE_FINAL.xlsx.

Original attack facts remain separated from RE:BORN modernization. Static sprite sheets do not establish exact frame timing; timing values are PLAYTEST-TUNABLE.
