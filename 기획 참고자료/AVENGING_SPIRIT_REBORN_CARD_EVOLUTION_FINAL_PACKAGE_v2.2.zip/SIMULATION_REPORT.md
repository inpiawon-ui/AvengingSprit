# Simulation Report

Seed: 0x9e3779b9. 45 configurations × 100,000 Runs = 4,500,000 deterministic Runs.

Average Evolutions per Run across all configurations: 1.386.
Legendary seen: 65.39%.
Compatibility: {"FULL":680,"ADAPTED":88,"LIMITED":32,"INCOMPATIBLE":0}.
