import fs from 'node:fs';
import { FileBlob, SpreadsheetFile } from '@oai/artifact-tool';
const load=n=>JSON.parse(fs.readFileSync(new URL(n,import.meta.url),'utf8'));
const cards=load('./CARD_MASTER_RUNTIME.json');
const procs=load('./CARD_PROC_RULE_RUNTIME.json');
const evos=load('./EVOLUTION_RUNTIME.json');
const recipes=load('./RECIPE_RUNTIME.json');
const compat=load('./HOST_CARD_COMPATIBILITY.json');
const mc=load('./MONTE_CARLO_RESULTS.json');
const stale=['Mobile Assault','Closing Drive','Spectral Deployment','Evolution Catalyst','Trait A + Trait B'];
const corpus=JSON.stringify({cards,procs,evos,recipes,compat});
const errors=[];
if(cards.cards.length!==32) errors.push('CARD_COUNT');
if(evos.evolutions.length!==11) errors.push('EVOLUTION_COUNT');
if(recipes.recipes.length!==11) errors.push('RECIPE_COUNT');
if(recipes.starterRecipeIds.length!==2) errors.push('STARTER_COUNT');
if(compat.matrix.length!==800) errors.push('COMPATIBILITY_COUNT');
if(mc.totalRuns!==4500000||mc.results.length!==45) errors.push('MONTE_CARLO_COUNT');
const ids=new Set(cards.cards.map(x=>x.cardId));
for(const r of recipes.recipes) if(!ids.has(r.cardA)||!ids.has(r.cardB)) errors.push(`MISSING_INGREDIENT_${r.evolutionId}`);
const unlockByCard=Object.fromEntries(cards.cards.map(x=>[x.cardId,x.unlock]));
for(const r of recipes.recipes){
  const ok=x=>r.unlock==='STARTER_RECIPE'?x==='DEFAULT':x==='DEFAULT'||String(x).includes(r.unlock);
  if(!ok(unlockByCard[r.cardA])||!ok(unlockByCard[r.cardB])) errors.push(`CROSS_HOST_LOCK_${r.evolutionId}`);
}
for(const s of stale) if(corpus.includes(s)) errors.push(`STALE_${s}`);
const workbook=await SpreadsheetFile.importXlsx(await FileBlob.load(new URL('./AVENGING_SPIRIT_REBORN_CARD_BUILD_EVOLUTION_MASTER_v2.2_FINAL_LOCK.xlsx',import.meta.url).pathname));
const sheetInfo=await workbook.inspect({kind:'sheet',include:'id,name',maxChars:20000});
const xlsxStale=[];
for(const line of (sheetInfo.ndjson||'').split('\n')){
  let name; try{name=JSON.parse(line).name;}catch{continue;} if(!name)continue;
  const used=workbook.worksheets.getItem(name).getUsedRange(true); if(!used)continue;
  const values=used.values;
  for(let r=0;r<values.length;r++)for(let c=0;c<values[r].length;c++)if(typeof values[r][c]==='string')for(const s of stale)if(values[r][c].includes(s))xlsxStale.push({sheet:name,row:r+1,col:c+1,term:s});
}
if(xlsxStale.length) errors.push(...xlsxStale.map(x=>`XLSX_STALE_${x.sheet}_R${x.row}C${x.col}_${x.term}`));
if(!procs.echoWhitelist.includes('BASIC_ATTACK_PROFILE')) errors.push('ECHO_WHITELIST');
if(!procs.echoBlacklist.includes('EVOLUTION')||!procs.echoBlacklist.includes('ECHO')) errors.push('ECHO_BLACKLIST');
console.log(JSON.stringify({status:errors.length?'FAIL':'PASS',xlsxCellScan:'ALL WORKSHEETS / ALL USED CELLS',xlsxStale,errors},null,2));
process.exitCode=errors.length?1:0;
