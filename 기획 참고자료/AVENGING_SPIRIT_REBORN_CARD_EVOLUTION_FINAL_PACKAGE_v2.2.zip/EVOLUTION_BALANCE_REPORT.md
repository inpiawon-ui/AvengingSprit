# Evolution Balance

11 automatic Run-persistent Evolutions. Boss fallback: 11/11. Max slots: 3. Numeric values are DATA LOCKED prototypes and PLAYTEST-TUNABLE only within workbook guardrails.
