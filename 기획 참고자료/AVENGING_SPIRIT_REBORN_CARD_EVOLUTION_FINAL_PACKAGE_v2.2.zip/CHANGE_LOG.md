# Change Log · v2.2 FINAL LOCK

Six approved card redesigns propagated across XLSX, UI, JSON, Research, Simulation, Visuals and QA.

- C002: single-target damage semantics locked.
- C005: 4-hit interpolation and 1.5s reset locked.
- C022: Mobile Assault → Quick Setup; 0.18s / 55% wind-up floor.
- C024: Closing Drive → Combat Step; 1.2s player-directed reposition buff.
- C030: Spectral Deployment → Spectral Turret; 8-hit trigger, non-recursive pooled entity.
- C032: Evolution Catalyst → Spectral Echo; explicit whitelist/blacklist.
- EVO01/EVO03 are Starter Recipes; H23/H18 Lv7 rewards replaced with bounded Evolution mastery bonuses.
- 11 recipes are player-facing Card A + Card B.
- `36_CARD_HEALTH_QA` was fully rebuilt from the current v2.2 compatibility matrix; four deprecated card names were removed.
- The Validator now scans every used cell in every XLSX worksheet for deprecated terminology.
- C025 unlock: H07 Lv7 or H21 Lv7, preserving EVO08 while making EVO06 immediately actionable.
- C013 unlock: H03 Lv7 or H06 Lv7, preserving EVO10 while making EVO07 immediately actionable.
- C012 unlock: Area Research or H15 Lv7 or H21 Lv7, making EVO09 and EVO06 immediately actionable.
- Recipe Access QA now computes route validity; 11/11 recipes have zero mandatory cross-Host ingredient locks.
