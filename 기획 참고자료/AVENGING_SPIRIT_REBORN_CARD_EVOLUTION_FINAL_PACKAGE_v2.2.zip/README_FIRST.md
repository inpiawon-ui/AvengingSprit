# AVENGING SPIRIT RE:BORN · Card / Evolution v2.2

Development Source of Truth:

1. `AVENGING_SPIRIT_REBORN_CARD_BUILD_EVOLUTION_MASTER_v2.2_FINAL_LOCK.xlsx`
2. `AVENGING_SPIRIT_REBORN_25_HOST_MASTER_DB_v2.2_FINAL_LOCK_SYNC.xlsx`
3. Runtime JSON files

System and data definitions are locked. Damage, cooldown, probability, Gold and selected caps remain playtest-tunable only inside the documented guardrails. Unity gameplay playtest has not been represented as completed.

Run `node validate_v22.mjs` to verify counts, IDs, recipes, compatibility, Monte Carlo totals, stale terms and C032 recursion safeguards.
